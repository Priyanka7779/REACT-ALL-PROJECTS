import React from 'react';
import Card from './component/Card';

function App() {
    return (
        <div>
            <h1 style={text-align-center}>User Card</h1>
          
            <Card />

        </div>
    )
}

export default App